package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.image.*;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.ResourceBundle;


public class LoginController implements EventHandler<ActionEvent>, Initializable {

	private Stage stage;
	private Scene scene;
	private Parent root;

	private HashMap<String, String> hMap;

	@FXML
	private ImageView calculatorImage;
	
	@FXML
	private ImageView lockImage;
	
	@FXML
	private Button button1;

	@FXML
	private Button button2;

	@FXML
	private TextField username1;

	@FXML
	private TextField username2;

	@FXML
	private PasswordField password1;

	@FXML
	private PasswordField password2;

	@FXML
	private Label wrongLogIn;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		hMap = new HashMap<String, String>();
		Image image1 = new Image(getClass().getResourceAsStream("img/calculator_login.jpg"));
		Image image2 = new Image(getClass().getResourceAsStream("img/lock_login.png"));
		
		calculatorImage = new ImageView();
		lockImage = new ImageView();
		
		calculatorImage.setImage(image1);
		lockImage.setImage(image2);
		
	}
	
	@Override
	public void handle(ActionEvent event) {
		String q = username1.getText();
		String w = password1.getText();

		if(!hMap.containsKey(q) || !hMap.containsValue(w)) {
			System.out.println(hMap.containsKey(q));
			wrongLogIn.setText("Wrong username or password.");
		}
		else {
			System.out.println(hMap.containsKey(q));
			wrongLogIn.setText("Logging In");
			
			try {
				root = FXMLLoader.load(getClass().getResource("fxml/HomePage.fxml"));
				stage = (Stage)((Node)event.getSource()).getScene().getWindow();
				scene = new Scene(root,600,400);
				stage.setScene(scene);
				stage.show();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	public void switchToScene2(ActionEvent event) throws IOException{
		
		root = FXMLLoader.load(getClass().getResource("fxml/Account.fxml"));
//		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
 		stage = (Stage) button2.getScene().getWindow();
		scene = new Scene(root,600,400);
		stage.setScene(scene);
//		stage.show();
		
		
		
	}

	public void printHashMap()
	{
		System.out.println(hMap);
	}

	public void sendToLogin(String user, String pass)
	{
		hMap.put(user, pass);
	}





}