package application;

import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.ResourceBundle;

import application.data.Student;
import application.data.Course;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.text.DecimalFormat;

public class CalculatorController implements Initializable
{
	public Student student = new Student();
	private ArrayList<Course> courses;
	
//	private ArrayList<Label> labels;
//	private ArrayList<ChoiceBox<String>> choicesboxes;
//	private ArrayList<TextField> textfields;
	
	// JavaFX components
	@FXML private Label course1Label;
	@FXML private Label course2Label;
	@FXML private Label course3Label;
	@FXML private Label course4Label;
	@FXML private Label course5Label;
	@FXML private Label course6Label;
	@FXML private Label course7Label;
	@FXML private Label course8Label;
	
	@FXML private ChoiceBox<String> letterGradeChoice1;
	@FXML private ChoiceBox<String> letterGradeChoice2;
	@FXML private ChoiceBox<String> letterGradeChoice3;
	@FXML private ChoiceBox<String> letterGradeChoice4;
	@FXML private ChoiceBox<String> letterGradeChoice5;
	@FXML private ChoiceBox<String> letterGradeChoice6;
	@FXML private ChoiceBox<String> letterGradeChoice7;
	@FXML private ChoiceBox<String> letterGradeChoice8;
	
	@FXML private TextField creditsHours1;
	@FXML private TextField creditsHours2;
	@FXML private TextField creditsHours3;
	@FXML private TextField creditsHours4;
	@FXML private TextField creditsHours5;
	@FXML private TextField creditsHours6;
	@FXML private TextField creditsHours7;
	@FXML private TextField creditsHours8;
	
	
	@FXML private VBox vbox;

	@FXML private Label displayGPA;
	
	@FXML private Button calculateButton;
	@FXML private Button addSemesterButton;
	@FXML private Button addCourseButton;
	
	ObservableList<String> oList = FXCollections.observableArrayList();
	
	private String[] letterGradesSet = {"", "A+", "A", "A-",
										"B+", "B", "B-",
										"C+", "C", "C-",
										"D+", "D", "F"};

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) 
	{
		vbox = new VBox();
		vbox.setSpacing(5);
		oList.removeAll();
		oList.addAll(letterGradesSet);
	}
	
	public void calculate()
	{
		retrieveData();
		student.setCourses(courses);
		student.calculateCumulativeGPA();
		
		double GPA =  student.getCumulativeGPA();
		
		DecimalFormat df = new DecimalFormat("###.##");
		displayGPA.setText("Your Cumulative GPA is: " + df.format(GPA));
		
//		displayGPA.setText("Your Cumulative GPA is: " + String.valueOf(GPA));
	}
	
	public void retrieveData()
	{
		// retrive selected letter grade
		int i = 0;
		if (i < courses.size()) {
			courses.get(i).setLetterGrade(letterGradeChoice1.getValue());
			i++;
		}
		if (i < courses.size()) {
			courses.get(i).setLetterGrade(letterGradeChoice2.getValue());
			i++;
		}
		if (i < courses.size()) {
			courses.get(i).setLetterGrade(letterGradeChoice3.getValue());
			i++;
		}
		if (i < courses.size()) {
			courses.get(i).setLetterGrade(letterGradeChoice4.getValue());
			i++;
		}
		if (i < courses.size()) {
			courses.get(i).setLetterGrade(letterGradeChoice5.getValue());
			i++;
		}
		if (i < courses.size()) {
			courses.get(i).setLetterGrade(letterGradeChoice6.getValue());
			i++;
		}
		if (i < courses.size()) {
			courses.get(i).setLetterGrade(letterGradeChoice7.getValue());
			i++;
		}
		if (i < courses.size()) {
			courses.get(i).setLetterGrade(letterGradeChoice8.getValue());
		}
		
		// retrieve credit hours
		i = 0;
		if (i < courses.size() && creditsHours1.getText() != "") {
			courses.get(i).setCreditHours(Integer.parseInt(creditsHours1.getText()));
			i++;
		}
		if (i < courses.size() && creditsHours2.getText() != "") {
			courses.get(i).setCreditHours(Integer.parseInt(creditsHours2.getText()));
			i++;
		}
		if (i < courses.size() && creditsHours3.getText() != "") {
			courses.get(i).setCreditHours(Integer.parseInt(creditsHours3.getText()));
			i++;
		}
		if (i < courses.size() && creditsHours4.getText() != "") {
			courses.get(i).setCreditHours(Integer.parseInt(creditsHours4.getText()));
			i++;
		}
		if (i < courses.size() && creditsHours5.getText() != "") {
			courses.get(i).setCreditHours(Integer.parseInt(creditsHours5.getText()));
			i++;
		}
		if (i < courses.size() && creditsHours6.getText() != "") {
			courses.get(i).setCreditHours(Integer.parseInt(creditsHours6.getText()));
			i++;
		}
		if (i < courses.size() && creditsHours7.getText() != "") {
			courses.get(i).setCreditHours(Integer.parseInt(creditsHours7.getText()));
			i++;;
		}
		if (i < courses.size() && creditsHours8.getText() != "") {
			courses.get(i).setCreditHours(Integer.parseInt(creditsHours8.getText()));
		}
		
	}
	
	public void createDataInput(Student s)
	{
		student = s;
		courses = student.getCourses();
		int i = 0;
		
		
		if (i < courses.size()) {
			course1Label.setText(courses.get(i).getCourseName());
			letterGradeChoice1.setItems(oList);
			letterGradeChoice1.setDisable(false);
			creditsHours1.setEditable(true);
			creditsHours1.setDisable(false);
			i++;
		}
		
		if (i < courses.size()) {
			course2Label.setText(courses.get(i).getCourseName());
			letterGradeChoice2.setItems(oList);
			letterGradeChoice2.setDisable(false);
			creditsHours2.setEditable(true);
			creditsHours2.setDisable(false);
			i++;
		}
		
		if (i < courses.size()) {
			course3Label.setText(courses.get(i).getCourseName());
			letterGradeChoice3.setItems(oList);
			letterGradeChoice3.setDisable(false);
			creditsHours3.setEditable(true);
			creditsHours3.setDisable(false);
			i++;
		}
		if (i < courses.size()) {
			course4Label.setText(courses.get(i).getCourseName());
			letterGradeChoice4.setItems(oList);
			letterGradeChoice4.setDisable(false);
			creditsHours4.setEditable(true);
			creditsHours4.setDisable(false);
			i++;
		}
		if (i < courses.size()) {
			course5Label.setText(courses.get(i).getCourseName());
			letterGradeChoice5.setItems(oList);
			letterGradeChoice5.setDisable(false);
			creditsHours5.setEditable(true);
			creditsHours5.setDisable(false);
			i++;
		}
		if (i < courses.size()) {
			course6Label.setText(courses.get(i).getCourseName());
			letterGradeChoice6.setItems(oList);
			letterGradeChoice6.setDisable(false);
			creditsHours6.setEditable(true);
			creditsHours6.setDisable(false);
			i++;
		}
		if (i < courses.size()) {
			course7Label.setText(courses.get(i).getCourseName());
			letterGradeChoice7.setItems(oList);
			letterGradeChoice7.setDisable(false);
			creditsHours7.setEditable(true);
			creditsHours7.setDisable(false);
			i++;
		}
		
		if (i < courses.size()) {
			course8Label.setText(courses.get(i).getCourseName());
			letterGradeChoice8.setItems(oList);
			letterGradeChoice8.setDisable(false);
			creditsHours8.setEditable(true);
			creditsHours8.setDisable(false);
		}

		
		/*
		for (int i = 0; i < courses.size(); i++)
		{
			// creating label
			Label newLabel = new Label();
			newLabel.setText("" + courses.get(i).getCourseName());
			
			// creating choicebox
			oList.removeAll();
			oList.addAll(letterGradesSet);
			ChoiceBox<String> choicebox = new ChoiceBox<String>(oList);
	
			// creating textfield
			TextField newText = new TextField();
			newText.setPrefWidth(120);
			newText.setPromptText("# of credit hours");
			
			// add to respective ArrayLists
			labels.add(newLabel);
			choicesboxes.add(choicebox);
			textfields.add(newText);
		}
		
		// add hbox to vbox
		vbox.getChildren().add(hbox);
		*/
		
		
	}
	
	public void backToHomePage(ActionEvent event)
	{
		try
		{
			Parent root = FXMLLoader.load(getClass().getResource("fxml/HomePage.fxml"));
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root,600,400);
			stage.setScene(scene);
			stage.show();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
}
