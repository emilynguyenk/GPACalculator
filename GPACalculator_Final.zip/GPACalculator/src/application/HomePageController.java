package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.data.Student;

public class HomePageController implements Initializable
{
	Student student = new Student();
	
	private Parent root;
	private Stage stage;
	private Scene scene;
	
	@FXML private ImageView coursesImage;
	@FXML private ImageView calculatorImage;
	
	@FXML private Button coursesButton;
	@FXML private Button calculatorButton;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) 
	{
		Image image1 = new Image(getClass().getResourceAsStream("img/course_pic_2.png"));
		Image image2 = new Image(getClass().getResourceAsStream("img/calculator_pic.png"));
		
		coursesImage = new ImageView();
		calculatorImage = new ImageView();
		
		coursesImage.setImage(image2);
		calculatorImage.setImage(image1);
	}
	
	@FXML
	public void openCourses(ActionEvent event)
	{
		try
		{
			root = FXMLLoader.load(getClass().getResource("fxml/CoursesPage.fxml"));
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root,600,400);
			
			stage.setScene(scene);
			stage.show();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	@FXML
	public void openCalculator(ActionEvent event)
	{
		try 
		{
			FXMLLoader loader2 = new FXMLLoader();
			loader2.setLocation(getClass().getResource("fxml/Calculator.fxml"));
			Parent root2 = loader2.load();
			
			scene = new Scene(root2);
			
			CalculatorController controller2 = loader2.getController();
			controller2.createDataInput(student);
			
			stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
			stage.setScene(scene);
			stage.show();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}

	}
	
	@FXML
	public void logOut(ActionEvent event)
	{
		try 
		{
			root = FXMLLoader.load(getClass().getResource("fxml/Login.fxml"));
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root,600,400);
			stage.setScene(scene);
			stage.show();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void sendToHomePage(Student student)
	{
		this.student = student;
	}


}
	
	
