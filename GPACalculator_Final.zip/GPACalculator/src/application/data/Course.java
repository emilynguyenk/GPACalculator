package application.data;

/**
 * The Course class will represent a Course object.
 * Each Course objects contains information about each course:
 * the name, number of credit hours, letter grade, and grade points.
 * @author Tyler Nguyen
 * @author Gabby Mapa
 * @author Emily Nguyen
 *
 */

public class Course 
{
	private String courseName;
	private int creditHours;
	private String letterGrade;
	private double gradePoints;
	
	private String daySched;
	private String timeSched;
	
	public Course() 
	{
		courseName = "";
		creditHours = 0;
		letterGrade = "";
		gradePoints = 0.0;
		
		daySched = "";
		timeSched = "";
	}
	
	public double letterGradeToGradePoints()
	{
		// determine grade points based on letter grade
		switch (letterGrade)
		{
			case "": this.gradePoints = 0.0;
				break;
		
			case "A+": this.gradePoints = 4.0;
				break;
			case "A": this.gradePoints = 4.0;
				break;
			case "A-": this.gradePoints = 3.7;
				break;
				
			case "B+": this.gradePoints = 3.3;
				break;
			case "B": this.gradePoints = 3.0;
				break;
			case "B-": this.gradePoints = 2.7;
				break;
			
			case "C+": this.gradePoints = 2.3;
				break;
			case "C": this.gradePoints = 2.0;
				break;
			case "C-": this.gradePoints = 1.7;
				break;
			
			case "D+": this.gradePoints = 1.3;
				break;
			case "D": this.gradePoints = 1.0;
				break;
			case "F": this.gradePoints = 0.0;
				break;
				
		}
		
		return this.gradePoints;
	}
	
	public String getCourseName() {
		return courseName;
	}
	
	public int getCreditHours() {
		return creditHours;
	}
	
	public String getLetterGrade()	{
		return letterGrade;
	}
	
	public double getGradePoints()	{
		return letterGradeToGradePoints();
	}
	
	public String getDaySched() {
		return daySched;
	}

	public String getTimeSched() {
		return timeSched;
	}
	

	public void setCourseName(String courseName)	{
		this.courseName = courseName;
	}
	
	public void setCreditHours(int creditHours)	{
		this.creditHours = creditHours;
	}
	
	public void setLetterGrade(String letterGrade)	{
		this.letterGrade = letterGrade;
	}
	
	public void setGradePoints(double gradePoints)	{
		this.gradePoints = gradePoints;
	}

	public void setDaySched(String daySched) {
		this.daySched = daySched;
	}

	public void setTimeSched(String timeSched) {
		this.timeSched = timeSched;
	}
	
	
}
