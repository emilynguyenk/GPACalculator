package application.data;

public final class StudentHolder 
{
	private Student student;
	
	private final static StudentHolder INSTANCE = new StudentHolder();
	
	private StudentHolder() {}
	
	public static StudentHolder getInstance()	{
		return INSTANCE;
	}
	
	public void setStudent(Student s) {
		this.student = s;
	}
	
	public Student getStudent()
	{
		return this.student;
	}
	
	
	
}
