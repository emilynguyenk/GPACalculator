package application;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import application.data.Course;
import application.data.Student;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CoursesPageController implements Initializable {
	
	public Student student = new Student();
	
	private ArrayList<String> studCourses;
	private ArrayList<String> daySched;
	private ArrayList<String> timeSched;
	private int numCoursesEntered;
	
	@FXML
	private Button Enter;
	
	@FXML
	private Button Done;
	
	@FXML
	private TextField textField;
	
	@FXML
	private TextField textField2;
	
	@FXML
	private TextField textField3;
	
	@FXML
	private Label maxCourses;
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
		studCourses = new ArrayList<>();
		daySched = new ArrayList<>();
		timeSched = new ArrayList<>();
		numCoursesEntered = 1;
	}
	


	
	public void enterCourse(ActionEvent event) {
		Course course = new Course();
		
		maxCourses.setText("");
		String newCourse = textField.getText();
		String newDaySched = textField2.getText();
		String newTimeSched = textField3.getText();
		if(numCoursesEntered >= 8) {
			maxCourses.setText("\tERROR: max number of courses reached.");
		}
		else {
			daySched.add(newDaySched);
			course.setDaySched(newDaySched);
			
			studCourses.add(newCourse);
			course.setCourseName(newCourse);
			
			timeSched.add(newTimeSched);
			course.setTimeSched(newTimeSched);
			
			numCoursesEntered++;
			
			textField.setText("");
			textField2.setText("");
			textField3.setText("");
			
			student.addCourse(course);
		}
	}
	
	public void handle(ActionEvent event) {
		try 
		{
			Stage stage = new Stage();
			FXMLLoader loader = new FXMLLoader(getClass().getResource("fxml/CoursesPagePart2.fxml"));
			Parent root = loader.load();
			CoursesPagePart2Controller controller = loader.getController();
			if(studCourses.isEmpty()) {
				maxCourses.setText("\t\t\tERROR: enter course(s).");
			}
			else {
				
				FXMLLoader loader2 = new FXMLLoader();
				loader2.setLocation(getClass().getResource("fxml/Calculator.fxml"));
				Parent root2 = loader2.load();
				
				Scene scene2 = new Scene(root2);
				
				CalculatorController controller2 = loader2.getController();
				controller2.createDataInput(student);
				
				Stage stage2 = (Stage) ((Node)event.getSource()).getScene().getWindow();
				stage2.setScene(scene2);
				stage2.show();
				
				controller.showInformation(0, studCourses.get(0), daySched.get(0), timeSched.get(0));
			
				for(int i = 0; i < studCourses.size(); i++) 
				{
					controller.showInformation(i, studCourses.get(i), daySched.get(i), timeSched.get(i));
				}
				
				stage.setX(root.getTranslateX()+650);
				stage.setScene(new Scene(root));
				stage.setTitle("Schedule");
				stage.show();
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		

	}
	
//	@FXML
//	private void sendData(ActionEvent event)
//	{
//		Student student = new Student();
//		Node node = (Node) event.getSource();
//		
//		Stage stage = (Stage) node.getScene().getWindow();
//		stage.close();
//		try
//		{
//			Parent root = FXMLLoader.load(getClass().getResource("/application/fxml/Calculator.fxml"));
//			StudentHolder holder = StudentHolder.getInstance();
//			holder.setStudent(student);
//			
//			stage.setUserData(student);
//			
//			Scene scene = new Scene(root);
//			stage.setScene(scene);
//			stage.show();
//		}
//		catch (IOException e)
//		{
//			e.printStackTrace();
//		}
//	}
	
	public void backToHomePage(ActionEvent event)
	{
		try
		{
			Parent root = FXMLLoader.load(getClass().getResource("fxml/HomePage.fxml"));
			Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			Scene scene = new Scene(root,600,400);
			stage.setScene(scene);
			stage.show();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	
	
}